var searchData=
[
  ['student_0',['Student',['../class_student.html',1,'']]],
  ['students_2ecpp_1',['Students.cpp',['../_students_8cpp.html',1,'']]],
  ['students_2eh_2',['Students.h',['../_students_8h.html',1,'']]],
  ['surname_3',['surname',['../class_person.html#afe1083690054fc69072866693d2b6f5a',1,'Person']]]
];
