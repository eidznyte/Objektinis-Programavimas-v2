var searchData=
[
  ['operator_3c_3c_0',['operator&lt;&lt;',['../class_student.html#aadd1864a776093e95f449dc91906f9eb',1,'Student::operator&lt;&lt;'],['../_students_8cpp.html#aadd1864a776093e95f449dc91906f9eb',1,'operator&lt;&lt;(std::ostream &amp;out, const Student &amp;student):&#160;Students.cpp'],['../_students_8h.html#aadd1864a776093e95f449dc91906f9eb',1,'operator&lt;&lt;(std::ostream &amp;out, const Student &amp;student):&#160;Students.cpp']]],
  ['operator_3e_3e_1',['operator&gt;&gt;',['../class_student.html#a346086824d08147b8544ca5403748e5d',1,'Student::operator&gt;&gt;'],['../_students_8cpp.html#a346086824d08147b8544ca5403748e5d',1,'operator&gt;&gt;(std::istream &amp;in, Student &amp;student):&#160;Students.cpp'],['../_students_8h.html#a346086824d08147b8544ca5403748e5d',1,'operator&gt;&gt;(std::istream &amp;in, Student &amp;student):&#160;Students.cpp']]]
];
