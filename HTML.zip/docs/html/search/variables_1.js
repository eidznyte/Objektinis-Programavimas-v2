var searchData=
[
  ['surname_0',['surname',['../class_person.html#afe1083690054fc69072866693d2b6f5a',1,'Person']]]
];
