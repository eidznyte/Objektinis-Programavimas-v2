var searchData=
[
  ['operator_3c_3c_0',['operator&lt;&lt;',['../class_student.html#aadd1864a776093e95f449dc91906f9eb',1,'Student']]],
  ['operator_3e_3e_1',['operator&gt;&gt;',['../class_student.html#a346086824d08147b8544ca5403748e5d',1,'Student']]]
];
