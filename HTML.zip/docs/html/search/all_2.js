var searchData=
[
  ['generatefile_0',['generatefile',['../_students_8cpp.html#accc62faeade35bf3c3f5629a06d76a92',1,'generateFile(const std::string &amp;filename, int numStudents):&#160;Students.cpp'],['../_students_8h.html#accc62faeade35bf3c3f5629a06d76a92',1,'generateFile(const std::string &amp;filename, int numStudents):&#160;Students.cpp']]],
  ['generaterandomscores_1',['generaterandomscores',['../_students_8cpp.html#a33ed06bc711157dd0e31f7562d4ae547',1,'generateRandomScores(Student &amp;student):&#160;Students.cpp'],['../_students_8h.html#a33ed06bc711157dd0e31f7562d4ae547',1,'generateRandomScores(Student &amp;student):&#160;Students.cpp']]]
];
