var searchData=
[
  ['inputstudentsmanually_0',['inputstudentsmanually',['../_students_8cpp.html#a7b9845870a8f3a59910a00d734593b5f',1,'inputStudentsManually(std::vector&lt; Student &gt; &amp;students):&#160;Students.cpp'],['../_students_8h.html#a7b9845870a8f3a59910a00d734593b5f',1,'inputStudentsManually(std::vector&lt; Student &gt; &amp;students):&#160;Students.cpp']]]
];
