var searchData=
[
  ['calculateaverage_0',['calculateaverage',['../_students_8cpp.html#a42faba302b4d7ffda6dc0faa21b318be',1,'calculateAverage(const std::vector&lt; int &gt; &amp;grades):&#160;Students.cpp'],['../_students_8h.html#a42faba302b4d7ffda6dc0faa21b318be',1,'calculateAverage(const std::vector&lt; int &gt; &amp;grades):&#160;Students.cpp']]],
  ['calculatemedian_1',['calculatemedian',['../_students_8cpp.html#a33fb3bba9f45ddaad1767848efcc3ff0',1,'calculateMedian(std::vector&lt; int &gt; grades):&#160;Students.cpp'],['../_students_8h.html#a33fb3bba9f45ddaad1767848efcc3ff0',1,'calculateMedian(std::vector&lt; int &gt; grades):&#160;Students.cpp']]],
  ['categorizestudents_2',['categorizestudents',['../_students_8cpp.html#a3a6dd89e15dce427d09e701766d929f9',1,'categorizeStudents(std::vector&lt; Student &gt; &amp;students, std::vector&lt; Student &gt; &amp;dummies):&#160;Students.cpp'],['../_students_8h.html#a3a6dd89e15dce427d09e701766d929f9',1,'categorizeStudents(std::vector&lt; Student &gt; &amp;students, std::vector&lt; Student &gt; &amp;dummies):&#160;Students.cpp']]]
];
