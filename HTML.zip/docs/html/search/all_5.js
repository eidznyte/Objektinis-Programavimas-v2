var searchData=
[
  ['name_0',['name',['../class_person.html#a7594663aadc0de77616506df8a2f4128',1,'Person']]]
];
